from django.contrib import admin
from . import views
from django.urls import path, include

urlpatterns = [
    path('index',views.index_client,name="client"),
    path('signup',views.signup_user,name='signup_user'),
    path('login',views.login_client,name='login_client'),
    path('orderfood',views.orderfood,name='orderfood'),
    path('bookings/<int:myid>', views.bookingfood, name='bookings'),

    path('addtocart/<int:myid>', views.addtocart, name='addtocart'),
    path('quantity/<int:myid>', views.quantity, name='quantity'),
    path('bookall', views.bookall, name='bookall'),
    path('bookcart/<str:data>', views.bookcart, name='bookcart'),
    # path('bookcart', views.ccc, name='ccc'),
    # path('bookcart', views.bookcart, name='bookcart'),

    path('delivered', views.agentdelivered, name='agentdelivered'),
    path('tobedelivered',views.tobedelivered,name='tobedelivered'),
    path('canceleddelivery',views.canceleddelivery,name='canceleddelivery'),
    path('cancelbookings/<int:myid>', views.cancelbookings, name='cancelbookings'),
    path('logout', views.logoutuser, name='logoutuser'),


    path('booked', views.booked, name='booked'),
    path('deletefromcart/<int:myid>', views.deletefromcart, name='deletefromcart'),
    path('update_quantity/<int:food_id>/', views.update_quantity, name='update_quantity'),
    path('restaurants/<int:myid>', views.singlerestaurants, name="singlerestaurants"),
    path('restaurants', views.allrestaurants, name="allrestaurants"),
    path('addcart/<int:myid>', views.addtocartres, name='addtocartres'),

    path('paymentforitems', views.paymentforitems, name='paymentforitems'),
    path("payment-status",views.paymentstatus,name='payment-status')

]
