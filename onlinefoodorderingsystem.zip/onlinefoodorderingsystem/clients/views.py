from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.db.models.fields import json
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt

from .models import Clients, Bookings, Cart, Payment
from restaurant.models import Restaurant, Food
from datetime import datetime, date

# Create your views here.
def index_client(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    return render(request,'clients/index.html')

def signup_user(request):
    if request.method == "POST":
        logoimg = request.FILES.get('image', None)
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        email=request.POST['email']
        username=request.POST['username']
        password=request.POST['password']
        confirmpassword=request.POST['confirmpassword']
        phone=request.POST['phone']
        address=request.POST['address']

        newuser = User.objects.create_user(first_name=firstname,last_name=lastname,email=email, username=username, password=password)
        newrestaurant = Clients.objects.create(user=newuser, phone=phone, address=address,image=logoimg,type="client")
        newuser.save()
        newrestaurant.save()
        return redirect('client')
    return render(request,'clients/signup_user.html')

def login_client(request):
    if request.method == "POST":
        username=request.POST['username']
        password=request.POST['password']
        user = authenticate(username=username, password=password)
        # print(user)
        if user is not None:
            user1 = Clients.objects.get(user=user)
            if user1.type == "client":
                login(request, user)
                return redirect("client")
        else:
            return render(request, "clients/login_user.html")
    return render(request,'clients/login_user.html')

def orderfood(request):
    if not request.user.is_authenticated:
        return redirect("login_client")
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    foods = Food.objects.all()
    clit = Clients.objects.get(user=request.user)
    cartfood=Cart.objects.filter(bookinguser=clit)
    data = []
    for i in cartfood:
        data.append(i.food.id)
    total_cost = sum(item.food.foodcost * item.quantity for item in cartfood)
    total_items = sum(item.quantity for item in cartfood)
    # print(total_cost,total_items)
    context = {
        'foods':foods,
        'cartfoods': cartfood,
        'total_cost': total_cost,
        'total_items': total_items,
        'data':data
    }
    # {'foods': foods, 'cartfoods': cartfood}
    return render(request, 'clients/orderfood.html',context)


def bookingfood(request,myid):
    if not request.user.is_authenticated:
        return redirect("login_client")
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    if request.method=="POST":
        vale=request.POST['vale']
        clit = Clients.objects.get(user=request.user)
        food = Food.objects.get(id=myid)
        newBook = Bookings(restaurant=food.restaurant, food=food, bookinguser=clit, quantity=vale, applydate=date.today(),
                           applytime=datetime.now().time(), satatus="Not Delivered",agentsid_id=True)
        if int(vale)>0:
            newBook.save()
        # print(vale)
    return redirect('orderfood')

def agentdelivered(request):
    if not request.user.is_authenticated:
        return redirect("login_client")
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    clit = Clients.objects.get(user=request.user)
    foods = Bookings.objects.filter(satatus="Delivered",bookinguser=clit).order_by('-applydate', 'applytime')
    # apply = Bookings.objects.filter(agentsid=clit)
    return render(request,"clients/history.html",{'foods':foods})

def tobedelivered(request):
    if not request.user.is_authenticated:
        return redirect("login_client")
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    clit = Clients.objects.get(user=request.user)
    foods = Bookings.objects.filter(satatus="Not Delivered", bookinguser=clit).order_by('-applydate', 'applytime')
    return render(request,'clients/tobedelivered.html',{'foods':foods})

def canceleddelivery(request):
    if not request.user.is_authenticated:
        return redirect("login_client")
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    clit = Clients.objects.get(user=request.user)
    foods = Bookings.objects.filter(satatus="Cancel Delivered", bookinguser=clit).order_by('-applydate', 'applytime')
    return render(request, 'clients/canceleddelivery.html', {'foods': foods})

def cancelbookings(request,myid):
    if not request.user.is_authenticated:
        return redirect("login_client")
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    foodie = get_object_or_404(Bookings, id=myid)
    foodie.satatus = "Cancel Delivered"
    foodie.save()
    return redirect('tobedelivered')

def logoutuser(request):
    logout(request)
    # return redirect('/user/index')
    return redirect('/')



def addtocart(request,myid):
    if not request.user.is_authenticated:
        return redirect("login_client")
    # print(myid)
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    clit = Clients.objects.get(user=request.user)
    food = Food.objects.get(id=myid)
    newBook = Cart(restaurant=food.restaurant, food=food, bookinguser=clit, quantity=1)
    newBook.save()
    if request.method=="POST":
        vale=request.POST['vale']
        print(vale)
    return redirect('orderfood')

def quantity(request,myid):
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    foodie = get_object_or_404(Cart, id=myid)
    if request.method=="POST":
        vale=request.POST['vale']
        foodie.quantity=vale
        foodie.save()
    return redirect('orderfood')


def bookall(request):
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    clit = Clients.objects.get(user=request.user)
    cartfood = Cart.objects.filter(bookinguser=clit)
    total_cost = sum(item.food.foodcost * item.quantity for item in cartfood)
    total_items = sum(item.quantity for item in cartfood)
    for foods in cartfood:
        # print(foods.quantity)
        # print(foods.food.restaurant)
        # print(foods.food)
        newBook = Bookings(restaurant=foods.food.restaurant, food=foods.food, bookinguser=clit, quantity=foods.quantity, applydate=date.today(),
                           applytime=datetime.now().time(), satatus="Not Delivered",agentsid_id=True)
        newBook.save()
    cartfood.delete()
    return redirect('orderfood')

def bookcart(request,data):
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    # print(data)
    return redirect('orderfood')

from django.http import HttpResponse

def bookcart(request, data):
    try:
        restaurants = Clients.objects.get(user=request.user)
    except:
        logoutuser(request)
        return redirect("/login")
    print(data)
    return redirect('orderfood')














def booked(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    if request.method=="POST":
        print("HI")
    foods = Food.objects.all()
    clit = Clients.objects.get(user=request.user)
    cartfood=Cart.objects.filter(bookinguser=clit)
    total_cost = sum(item.food.foodcost * item.quantity for item in cartfood)
    total_items = sum(item.quantity for item in cartfood)
    # print(total_cost,total_items)
    context = {
        'foods': foods,
        'cartfoods': cartfood,
        'total_cost': total_cost,
        'total_items': total_items,
    }
    return render(request,'clients/booked.html',context)


# views.py

def update_quantity(request, food_id):
    if request.method == 'POST':# and request.is_ajax():
        quantity = int(request.POST.get('quantity'))
        # print(quantity,food_id)
        foodie = get_object_or_404(Cart, food_id=food_id)
        foodie.quantity = quantity
        foodie.save()
        return JsonResponse({'message': 'Quantity updated successfully'}, status=200)

def singlerestaurants(request,myid):
    if not request.user.is_authenticated:
        return redirect("/login")
    foods = Food.objects.filter(restaurant_id=myid)
    clit = Clients.objects.get(user=request.user)
    cartfood = Cart.objects.filter(bookinguser=clit)
    data = []
    for i in cartfood:
        data.append(i.food.id)
    # foods=Food.objects.all()
    return render(request, 'clients/resfoodorder.html', {'foods':foods,'data':data})


def allrestaurants(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Restaurant.objects.all()
    return render(request, "clients/restaurants.html", {'restaurants': restaurants})

def addtocartres(request,myid):
    if not request.user.is_authenticated:
        return redirect("/login")
    clit = Clients.objects.get(user=request.user)
    food = Food.objects.get(id=myid)
    newBook = Cart(restaurant=food.restaurant, food=food, bookinguser=clit, quantity=1)
    newBook.save()
    return singlerestaurants(request,food.restaurant.id)


def deletefromcart(request,myid):
    restaurants = Cart.objects.filter(id=myid)
    restaurants.delete()
    return redirect('booked')



import razorpay
@csrf_exempt
def paymentforitems(request):
    client=razorpay.Client(auth=("rzp_test_WwBCla7kD4lfGX", "rsmiBqvgC3Xj5oIh5eBs3bhG"))
    user = Clients.objects.get(user=request.user)
    cart = Cart.objects.filter(bookinguser=user).order_by('id')
    total_cost = sum(item.food.foodcost * item.quantity for item in cart)
    total_items = sum(item.quantity for item in cart)
    number_as_float = float(total_cost)
    amount = int(number_as_float) * 100
    response_payment=client.order.create(dict(
            amount= amount,
            currency= "INR"
    ))
    # print(response_payment)
    order_id=response_payment['id']
    order_status=response_payment['status']

    if order_status=="created":
        Payment(bookinguser=user,amount=amount,order_id=order_id).save()
        response_payment['name']="ram"
        context = {
            'items': cart,
            'total_cost': total_cost,
            'total_items': total_items,
            'payment': response_payment
        }
        return render(request, "clients/userpaymentpage.html", context)
    return redirect("cartdata")




@csrf_exempt
def paymentstatus(request):
     response1 = request.POST
     params_dict = {
        "razorpay_payment_id": response1["razorpay_payment_id"],
        "razorpay_order_id": response1["razorpay_order_id"],
        "razorpay_signature": response1["razorpay_signature"]
     }
     # create razorpay client
     client=razorpay.Client(auth=("rzp_test_WwBCla7kD4lfGX", "rsmiBqvgC3Xj5oIh5eBs3bhG"))

     try:
         status = client.utility.verify_payment_signature(params_dict)
         coldcoffee = Payment.objects.get(order_id = response1['razorpay_order_id'])
         coldcoffee.razorpay_payment_id = response1['razorpay_payment_id']
         coldcoffee.paid = True
         coldcoffee.save()
         return redirect("bookall")
     except:
         return HttpResponse("Not Paid")

