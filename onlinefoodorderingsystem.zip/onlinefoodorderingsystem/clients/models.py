from django.contrib.auth.models import User
from django.db import models
from restaurant.models import Restaurant,Food
from deliveryagents.models import DeliveryAgent


# Create your models here.
class Clients(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=10)
    image = models.ImageField(upload_to="")
    type = models.CharField(max_length=15)
    address = models.TextField(max_length=1000)
    def __str__ (self):
        return self.user.username

class Bookings(models.Model):
    restaurant = models.CharField(max_length=200, default="")
    food = models.ForeignKey(Food, on_delete=models.CASCADE)
    bookinguser = models.ForeignKey(Clients, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    applydate = models.DateField()
    applytime = models.TimeField()
    agentsid = models.ForeignKey(DeliveryAgent, on_delete=models.CASCADE)
    # agentsid = models.IntegerField()
    satatus= models.TextField(max_length=99)
    def __str__ (self):
        return str(str(self.bookinguser)+"    "+str(self.restaurant))


class Cart(models.Model):
    restaurant = models.CharField(max_length=200, default="")
    food = models.ForeignKey(Food, on_delete=models.CASCADE)
    # student = models.ForeignKey(Student, on_delete=models.SET_NULL, null=True)
    bookinguser = models.ForeignKey(Clients, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    def __str__ (self):
        return str(str(self.bookinguser)+"    "+str(self.restaurant)+"    "+str(self.food))



class Contact(models.Model):
    name = models.CharField(max_length=65)
    mail = models.CharField(max_length=65)
    phone = models.CharField(max_length=10)
    rating = models.CharField(max_length=10)
    problem = models.CharField(max_length=100)
    address = models.TextField(max_length=1000)
    def __str__ (self):
        return self.name

class Payment(models.Model):
    bookinguser = models.ForeignKey(Clients, on_delete=models.CASCADE)
    amount=models.CharField(max_length=100)
    order_id = models.CharField(max_length=100,blank=True)
    razorpay_payment_id = models.CharField(max_length=100,blank=True)
    paid = models.BooleanField(default=False)