from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404

from .models import DeliveryAgent
from clients.models import Bookings


# Create your views here.
def deliveryagentindex(request):
    try:
        restaurants = DeliveryAgent.objects.get(user=request.user)
    except:
        logoutagent(request)
        return redirect("/login")
    return render(request,'agents/index.html')

def deliveryagentsignup(request):
    if request.method == "POST":
        usna=request.POST['username']
        passw=request.POST['password1']
        name=request.POST['name']
        gender=request.POST['gender']
        mail=request.POST['mail']
        phno=request.POST['phno']
        logoimg = request.FILES.get('logoimg', None)
        newuser = User.objects.create_user(first_name=name,email=mail,username=usna,password=passw)
        newagent = DeliveryAgent.objects.create(user=newuser, phone=phno, gender=gender,image=logoimg,
                                         type="agent", status="pending")
        newuser.save()
        newagent.save()
        # return redirect("deliveryagentindex")
    return render(request, 'agents/signup_agent.html')

def deliveryagentlogin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        userss = authenticate(username=username, password=password)
        # print(userss)
        if userss is not None:
            user1 = DeliveryAgent.objects.get(user=userss)
            if user1.type == "agent" and user1.status=="Accepted":
                login(request, userss)
                return redirect("deliveryagentindex")
        else:
            return render(request, "agents/login_agent.html")
    return render(request, 'agents/login_agent.html')


def viewordersagent(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    try:
        restaurants = DeliveryAgent.objects.get(user=request.user)
    except:
        logoutagent(request)
        return redirect("/login")
    orders = Bookings.objects.filter(satatus="Not Delivered").order_by('-applydate', 'applytime')
    clit = DeliveryAgent.objects.get(user=request.user)
    apply = Bookings.objects.filter(agentsid=clit)
    data = []
    for i in apply:
        data.append(i.id)
    return render(request,'agents/vieworders.html',{'orders': orders,'data':data})


def logoutagent(request):
    logout(request)
    # return redirect('deliveryagentindex')
    return redirect('/')

def acceptorder(request,myid):
    if not request.user.is_authenticated:
        return redirect("/deliveryagents/login")
    try:
        restaurants = DeliveryAgent.objects.get(user=request.user)
    except:
        logoutagent(request)
        return redirect("/login")
    foodie = get_object_or_404(Bookings, id=myid)
    clit = DeliveryAgent.objects.get(user=request.user)
    foodie.agentsid_id = clit
    foodie.save()
    return redirect('viewordersagent')

def cancelorder(request,myid):
    if not request.user.is_authenticated:
        return redirect("/deliveryagents/login")
    try:
        restaurants = DeliveryAgent.objects.get(user=request.user)
    except:
        logoutagent(request)
        return redirect("/login")
    foodie = get_object_or_404(Bookings, id=myid)
    foodie.agentsid_id = True
    foodie.save()
    return redirect('viewordersagent')

# def deliveredorder(request,myid):
#     foodie = get_object_or_404(Bookings, id=myid)
#     foodie.satatus = "Delivered"
#     foodie.save()
#     return redirect('viewordersagent')


def deliveredorder(request,myid):
    if not request.user.is_authenticated:
        return redirect("/deliveryagents/login")
    try:
        restaurants = DeliveryAgent.objects.get(user=request.user)
    except:
        logoutagent(request)
        return redirect("/login")
    foodie = get_object_or_404(Bookings,id=myid)
    if request.method == "POST":
        foodie.satatus = request.POST['status']
        foodie.save()
        return redirect('viewordersagent')
    return render(request, "agents/deliveredorder.html", {'restaru': foodie})


def mydelivers(request):
    if not request.user.is_authenticated:
        return redirect("/deliveryagents/login")
    try:
        restaurants = DeliveryAgent.objects.get(user=request.user)
    except:
        logoutagent(request)
        return redirect("/login")
    clit = DeliveryAgent.objects.get(user=request.user)
    orders = Bookings.objects.filter(satatus="Delivered",agentsid=clit).order_by('-applydate', 'applytime')
    return render(request, 'agents/mydelivers.html', {'orders': orders})