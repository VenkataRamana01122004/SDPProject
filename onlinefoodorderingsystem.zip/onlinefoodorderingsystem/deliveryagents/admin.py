from django.contrib import admin
from .models import DeliveryAgent
admin.site.register(DeliveryAgent)