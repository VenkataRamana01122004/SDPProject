import random

from django.conf import settings
from django.contrib import auth
from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.shortcuts import render, redirect

from restaurant.models import Restaurant
from deliveryagents.models import DeliveryAgent
from clients.models import Clients


def main(request):
    return render(request,'home.html')

def loginramana(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        # print(user)
        try:
            if user.is_superuser:
                login(request, user)
                return redirect("/adminpannel/index")
        except:
            return redirect("/login")
        try:
            rama = User.objects.get(username=username)
        except:
            rama=False
        if user is not None:
            try:
                user1 = Clients.objects.get(user=user)
                if user1.type == "client":
                    login(request, user)
                    return redirect("client")
            except:
                try:
                    user1 = DeliveryAgent.objects.get(user=user)
                    if user1.type == "agent" and user1.status == "Accepted":
                        login(request, user)
                        return redirect("deliveryagentindex")
                except:
                    try:
                        user1 = Restaurant.objects.get(user=user)
                        if user1.type == "restaurant" and user1.status == "Accepted":
                            login(request, user)
                            return redirect("index")
                    except:
                        if user.is_superuser:
                            login(request, user)
                            return redirect("/adminpannel/index")
                        # return redirect("/login")

        else:
            if rama :
                return render(request, "login.html",{'status':"User Password wrong"})
            else:
                return render(request, "login.html", {'status': "User Not Found"})
    return render(request,'login.html')

def signupram(request):
    return render(request,"signup.html")

from clients.models import Contact
def contactform(request):
    if request.method=="POST":
        name=request.POST['name']
        mail=request.POST['mail']
        phone=request.POST['phone']
        rating=request.POST['rating']
        problem=request.POST['problem']
        address=request.POST['address']
        Contact(name=name,mail=mail,phone=phone,rating=rating,problem=problem,address=address).save()
        tosend = 'From Team OFOS \nThanks for contact we are planning to resolve as fast as possible '+name
        send_mail(
            'Thank You for Contacting Online Food Ordering System',
            tosend,
            settings.EMAIL_HOST_USER,
            [mail],
            fail_silently=False,
        )
        # return redirect("main")
        return render(request,"home.html",{'status':True})
    return render(request,"contact.html")




def changepassword(request):
    if not request.user.is_authenticated:
        return redirect("userlogin")
    if request.method == "POST":
        password = request.POST['password']
        newpassword1 = request.POST['newpassword1']
        newpassword2 = request.POST['newpassword2']
        try:
            user = Restaurant.objects.get(user=request.user)
        except:
            try:
                user = DeliveryAgent.objects.get(user=request.user)
            except:
                user = Clients.objects.get(user=request.user)
        vvr = User.objects.get(id=user.user.id)
        if vvr.check_password(password):
            if newpassword1==newpassword2:
                new_password_hash = make_password(newpassword1)
                vvr.password = new_password_hash
                vvr.save()
                return render(request, "changepassword.html",{'status':"Password Updated sucess"})
            else:
                return render(request, "changepassword.html",{'status':"Both passwords are not same"})
        else:
            print("oldpass")
            return render(request, "changepassword.html", {'status': "old password is wrong"})
    return render(request, "changepassword.html")


def forgotpassword(request):
    if request.method == "POST":
        newpassword1 = request.POST['newpassword1']
        newpassword2 = request.POST['newpassword2']
        vvr = User.objects.filter(email=request.session.get('mail')).first()
        # print(vvr.username)
        if (vvr is None):
            return redirect("genpass")
        if newpassword1==newpassword2:
            # print(newpassword1)
            qwerty = make_password(newpassword1)
            vvr.password = qwerty
            vvr.save()
            # print(qwerty)
            return render(request, "forgotpasswordafter.html",{'status':"Password Updated sucess"})
        else:
            return render(request, "forgotpasswordafter.html",{'status':"Both passwords are not same"})
    return render(request, "forgotpasswordafter.html")


def genpass(request):
    otp=''
    vvr=request.session.get('mail')
    # print(vvr)
    if request.method=="POST":
        button_clicked = request.POST['submitbutton']
        if button_clicked == 'Submit':
            # print(vvr)
            mail=request.POST['mail']
            if not mail:
                return render(request, "forgotpassword.html")
            request.session['mail'] = mail
            for _ in range(4):
                otp += str(random.randint(0, 9))
            request.session['otp'] = otp
            # print(mail)
            # tosend = 'From Team SUPPORT TO FARMERS \nYour OTP : '+otp
            # send_mail(
            #     'Thank You for Contacting Online Food Ordering System',
            #     tosend,
            #     settings.EMAIL_HOST_USER,
            #     [mail],
            #     fail_silently=False,
            # )
            return render(request, "forgotpassword.html", {'otp': otp})

        if button_clicked == 'Resend':
            # print(vvr)
            for _ in range(4):
                otp += str(random.randint(0, 9))
            request.session['otp'] = otp
            tosend = 'From Team  \nYour OTP : ' + otp
            send_mail(
                'From The Team SUPPORT TO FARMERS',
                tosend,
                settings.EMAIL_HOST_USER,
                [vvr],
                fail_silently=False,
            )
            return render(request, "forgotpassword.html", {'otp': otp})
        elif button_clicked == 'Validate':
            valid = request.POST['valid']
            a = validateotp(request, valid)
            x = request.session.get('otp')
            if a:
                request.session['otp'] = None
                return redirect("forgotpassword")
            else:
                return render(request, "forgotpassword.html", {'otp': x})
    return render(request,"forgotpassword.html")

def validateotp(request,y):
    x=request.session.get('otp')
    # print(x)
    # print(y)
    if x==y:
        return True
    else:
        return False