"""
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.main,name='main'),
    path('login',views.loginramana,name='loginramana'),
    path('signup',views.signupram,name='signupram'),
    path('contact',views.contactform,name='contactform'),
    path('changepassword', views.changepassword, name='changepassword'),
    path('forgotpassword', views.forgotpassword, name='forgotpassword'),
    path('genpass', views.genpass, name='genpass'),

    path('restaurant/',include('restaurant.urls')),
    path('user/',include('clients.urls')),
    path('adminpannel/',include('adminpannel.urls')),
    path('deliveryagents/',include('deliveryagents.urls')),
    # path('', include('store.urls')),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
