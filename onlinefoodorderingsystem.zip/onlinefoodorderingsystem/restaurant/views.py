from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404

from .models import Restaurant, Food
from clients.models import Bookings


# Create your views here.
def index(request):
    try:
        restaurants = Restaurant.objects.get(user=request.user)
    except:
        Logout(request)
        return redirect("/login")
    return render(request,'restaurant/index.html')

def login_res(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        # print(user)
        if user is not None:
            user1 = Restaurant.objects.get(user=user)

            if user1.type == "restaurant" and user1.status=="Accepted":
                login(request, user)
                return redirect("index")
        else:
            return render(request, "restaurant/login.html")
    return render(request,"restaurant/login.html")

def signup(request):
    if request.method == "POST":
        usna=request.POST['username']
        passw=request.POST['password1']
        name=request.POST['name']
        restaurantname=request.POST['restaurantname']
        mail=request.POST['mail']
        phno=request.POST['phno']
        # logoimg = request.FILES['logoimg']
        logoimg = request.FILES.get('logoimg', None)
        newuser = User.objects.create_user(first_name=name,email=mail,username=usna,password=passw)
        newrestaurant = Restaurant.objects.create(user=newuser, phone=phno, restaurant_name=restaurantname,image=logoimg,
                                         type="restaurant", status="pending")
        newuser.save()
        newrestaurant.save()
        return redirect("index")
        # return HttpResponse("sucess")
    return render(request,'restaurant/signup.html')

def Logout(request):
    logout(request)
    # return redirect('/restaurant/index')
    return redirect('/')


def addfood(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    try:
        restaurants = Restaurant.objects.get(user=request.user)
    except:
        Logout(request)
        return redirect("/login")
    if request.method=="POST":
        foodname=request.POST['foodname']
        foodcost=request.POST['foodcost']
        # foodimage = request.FILES.get('foodimage', None)
        logoimg = request.FILES.get('logoimg', None)
        foodcategary = request.POST['foodcategary']
        foodtype=request.POST['foodtype']
        if 'veg'==foodtype:
            foodtype=True
        else:
            foodtype=False
        foodrating=request.POST['foodrating']
        user=request.user
        restaurant=Restaurant.objects.get(user=user)
        newfood=Food(restaurant=restaurant,foodname=foodname,foodcost=foodcost,foodimage=logoimg,foodcategary=foodcategary,foodtype=foodtype,
                     foodrating=foodrating)
        newfood.save()
        return redirect("fooddetails")
        # return HttpResponse("food saved")
    return render(request,"restaurant/addfood.html")

def fooddetails(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    try:
        restaurants = Restaurant.objects.get(user=request.user)
    except:
        Logout(request)
        return redirect("/login")
    res = Restaurant.objects.get(user=request.user)
    foods = Food.objects.filter(restaurant=res)
    # foods=Food.objects.all()
    return render(request,'restaurant/fooddetails.html',{'foods':foods})

def fooddelete(request,myid):
    if not request.user.is_authenticated:
        return redirect("login")
    try:
        restaurants = Restaurant.objects.get(user=request.user)
    except:
        Logout(request)
        return redirect("/login")
    foodie = Food.objects.filter(id=myid)
    foodie.delete()
    return redirect("fooddetails")

def foodupdate(request,myid):
    if not request.user.is_authenticated:
        return redirect("login")
    try:
        restaurants = Restaurant.objects.get(user=request.user)
    except:
        Logout(request)
        return redirect("/login")
    foodie = get_object_or_404(Food,id=myid)
    if request.method =="POST":
        foodname = request.POST['foodname']
        foodcost = request.POST['foodcost']
        foodimage = request.FILES.get('foodimage', None)
        foodcategary = request.POST['foodcategary']
        foodtype=request.POST['foodtype']
        if 'veg'==foodtype:
            foodie.foodtype=True
        else:
            foodie.foodtype=False
        foodrating = request.POST['foodrating']
        foodie.foodname=foodname
        foodie.foodcost=foodcost
        foodie.foodcategary=foodcategary
        foodie.foodrating=foodrating
        if foodimage!=None:
            foodie.foodimage=foodimage
        foodie.save()
        return redirect("fooddetails")
    return render(request,"restaurant/foodupdate.html",{'foodie':foodie})



def viewfoodorders(request):
    # orders=Bookings
    if not request.user.is_authenticated:
        return redirect("login")
    try:
        restaurants = Restaurant.objects.get(user=request.user)
    except:
        Logout(request)
        return redirect("/login")
    restaurant = Restaurant.objects.get(user=request.user)
    orders = Bookings.objects.filter(restaurant=restaurant,satatus="Not Delivered").order_by('-applydate','applytime')
    return render(request,'restaurant/viewfoodorders.html',{'orders':orders})
