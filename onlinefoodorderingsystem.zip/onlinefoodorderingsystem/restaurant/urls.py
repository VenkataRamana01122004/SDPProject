from . import views
from django.urls import path

urlpatterns = [
    path('index',views.index,name="index"),
    path('signup',views.signup,name='signup'),
    path('login',views.login_res,name='login'),
    path('logout',views.Logout,name="logout"),
    path('addfood',views.addfood,name="addfood"),
    path('fooddetails',views.fooddetails,name='fooddetails'),
    path('fooddelete/<int:myid>',views.fooddelete,name='fooddelete'),
    path('foodupdate/<int:myid>',views.foodupdate,name='foodupdate'),
    path('foodorders',views.viewfoodorders,name='viewfoodorders'),
]
