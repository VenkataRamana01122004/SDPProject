from django.contrib import admin


# Register your models here.
from .models import Restaurant,Food

# Register your models here.

admin.site.register(Restaurant)
admin.site.register(Food)