from django.contrib import admin

from .models import Clients, Bookings, Cart

# Register your models here.

admin.site.register(Bookings)
admin.site.register(Cart)
admin.site.register(Clients)