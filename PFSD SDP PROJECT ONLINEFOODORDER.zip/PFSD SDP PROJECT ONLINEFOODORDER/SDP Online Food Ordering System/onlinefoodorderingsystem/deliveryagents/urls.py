
from django.urls import path
from . import views

urlpatterns = [
    path('index',views.deliveryagentindex,name='deliveryagentindex'),
    path('signup',views.deliveryagentsignup,name='deliveryagentsignup'),
    path('login',views.deliveryagentlogin,name='deliveryagentlogin'),
    path('logout',views.logoutagent,name='logoutagent'),
    path('vieworders',views.viewordersagent,name='viewordersagent'),
    path('acceptorder/<int:myid>',views.acceptorder,name='acceptorder'),
    path('cancelorder/<int:myid>',views.cancelorder,name='cancelorder'),
    path('deliveredorder/<int:myid>',views.deliveredorder,name='deliveredorder'),
    path('mydelivers',views.mydelivers,name='mydelivers'),
]