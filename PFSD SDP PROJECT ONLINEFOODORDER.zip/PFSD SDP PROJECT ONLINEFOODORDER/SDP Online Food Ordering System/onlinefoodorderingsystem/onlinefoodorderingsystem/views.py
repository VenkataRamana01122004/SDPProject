from django.conf import settings
from django.contrib import auth
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.shortcuts import render, redirect

from restaurant.models import Restaurant
from deliveryagents.models import DeliveryAgent
from clients.models import Clients


def main(request):
    return render(request,'home.html')

def loginramana(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        # print(user)
        try:
            rama = User.objects.get(username=username)
            # print(rama)
        except:
            rama=False
        if user is not None:
            try:
                user1 = Clients.objects.get(user=user)
                if user1.type == "client":
                    login(request, user)
                    return redirect("client")
            except:
                try:
                    user1 = DeliveryAgent.objects.get(user=user)
                    if user1.type == "agent" and user1.status == "Accepted":
                        login(request, user)
                        return redirect("deliveryagentindex")
                except:
                    try:
                        user1 = Restaurant.objects.get(user=user)
                        if user1.type == "restaurant" and user1.status == "Accepted":
                            login(request, user)
                            return redirect("index")
                    except:
                        if user.is_superuser:
                            login(request, user)
                            return redirect("/adminpannel/index")
                        # return redirect("/login")

        else:
            if rama :
                return render(request, "login.html",{'status':"User Password wrong"})
            else:
                return render(request, "login.html", {'status': "User Not Found"})
    return render(request,'login.html')

def signupram(request):
    return render(request,"signup.html")

from clients.models import Contact
def contactform(request):
    if request.method=="POST":
        name=request.POST['name']
        mail=request.POST['mail']
        phone=request.POST['phone']
        rating=request.POST['rating']
        problem=request.POST['problem']
        address=request.POST['address']
        Contact(name=name,mail=mail,phone=phone,rating=rating,problem=problem,address=address).save()
        tosend = 'From Team OFOS \nThanks for contact we are planning to resolve as fast as possible '+name
        send_mail(
            'Thank You for Contacting Online Food Ordering System',
            tosend,
            settings.EMAIL_HOST_USER,
            [mail],
            fail_silently=False,
        )
        # return redirect("main")
        return render(request,"home.html",{'status':True})
    return render(request,"contact.html")