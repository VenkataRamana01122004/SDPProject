from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Restaurant(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=10)
    image = models.ImageField(upload_to="")
    type = models.CharField(max_length=15)
    status = models.CharField(max_length=20)
    restaurant_name = models.CharField(max_length=100)
    def __str__ (self):
        return self.user.username



class Food(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE)
    foodname = models.CharField(max_length=200)
    foodcost = models.FloatField()
    foodimage = models.ImageField(upload_to="")
    foodcategary = models.CharField(max_length=100)
    foodtype = models.BooleanField(default=False)
    foodrating = models.FloatField()

    def __str__ (self):
        return self.foodname