from . import views
from django.urls import path, include

urlpatterns = [
    path('index',views.index_admin,name="adminpannel"),
    path('restaurants',views.restaurants,name="restaurants"),
    path('updatestatus/<int:myid>',views.updatestatus,name="updatestatus"),
    path('deleterestaurant/<int:myid>',views.deleterestaurant,name="deleterestaurant"),
    path('pendingrestaurant',views.pendingrestaurant,name="pendingrestaurant"),
    path('acceptedrestaurant',views.acceptedrestaurant,name="acceptedrestaurant"),
    path('rejectedrestaurant',views.rejectedrestaurant,name="rejectedrestaurant"),
    path('delivaryagents',views.alldelivaryagents,name="alldelivaryagents"),
    path('agentstatusupdate/<int:myid>',views.agentstatusupdate,name="agentstatusupdate"),
    path('deleteagent/<int:myid>',views.deleteagent,name="deleteagent"),
    path('pendingagents', views.pendingagents, name="pendingagents"),
    path('acceptedagents', views.acceptedagents, name="acceptedagents"),
    path('rejectedagents', views.rejectedagents, name="rejectedagents"),
    path('clients', views.allclientsadmin, name="allclientsadmin"),
    path('deleteclient/<int:myid>',views.deleteclient,name="deleteclient"),
]
