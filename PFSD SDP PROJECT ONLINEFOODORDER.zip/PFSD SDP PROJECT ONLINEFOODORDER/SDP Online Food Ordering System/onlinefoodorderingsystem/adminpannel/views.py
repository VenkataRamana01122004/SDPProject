from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.shortcuts import render, get_object_or_404, redirect

from restaurant.models import Restaurant

from deliveryagents.models import DeliveryAgent

from clients.models import Clients


# Create your views here.
def index_admin(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    return render(request,"adminpannel/index.html")

def restaurants(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Restaurant.objects.all()
    return render(request,"adminpannel/restaurants.html",{'restaurants':restaurants})

def updatestatus(request,myid):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaru = get_object_or_404(Restaurant, id=myid)
    if request.method=="POST":
        restaru.status=request.POST['status']
        restaru.save()
        return redirect('restaurants')
    return render(request,"adminpannel/updatestatus.html",{'restaru':restaru})

def deleterestaurant(request,myid):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Restaurant.objects.filter(id=myid)
    restaurants.delete()
    return redirect('restaurants')

def rejectedrestaurant(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Restaurant.objects.filter(status="Rejected")
    return render(request, "adminpannel/rejectedrestaurant.html", {'restaurants': restaurants})

def pendingrestaurant(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Restaurant.objects.filter(status="pending")
    return render(request, "adminpannel/pendingrestaurant.html", {'restaurants': restaurants})

def acceptedrestaurant(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Restaurant.objects.filter(status="Accepted")
    return render(request, "adminpannel/acceptedrestaurant.html", {'restaurants': restaurants})

def alldelivaryagents(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = DeliveryAgent.objects.all()
    return render(request, "adminpannel/delivaryagents.html", {'restaurants': restaurants})

def agentstatusupdate(request,myid):
    if not request.user.is_authenticated:
        return redirect("/login")
    agent = get_object_or_404(DeliveryAgent, id=myid)
    if request.method == "POST":
        agent.status = request.POST['status']
        agent.save()
        return redirect('alldelivaryagents')
    return render(request, "adminpannel/updatestatus.html", {'restaru': agent})

def deleteagent(request,myid):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = DeliveryAgent.objects.filter(id=myid)
    restaurants.delete()
    return redirect('alldelivaryagents')

def rejectedagents(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = DeliveryAgent.objects.filter(status="Rejected")
    return render(request, "adminpannel/delivaryagents.html", {'restaurants': restaurants})

def pendingagents(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = DeliveryAgent.objects.filter(status="pending")
    return render(request, "adminpannel/delivaryagents.html", {'restaurants': restaurants})

def acceptedagents(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = DeliveryAgent.objects.filter(status="Accepted")
    return render(request, "adminpannel/delivaryagents.html", {'restaurants': restaurants})

def allclientsadmin(request):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Clients.objects.all()
    return render(request,"adminpannel/clients.html",{'restaurants': restaurants})

def deleteclient(request,myid):
    if not request.user.is_authenticated:
        return redirect("/login")
    restaurants = Clients.objects.filter(id=myid)
    restaurants.delete()
    return redirect('allclientsadmin')

# def logoutadminramana(request):
#     logout(request)
#     # return redirect('/user/index')
#     return redirect('/')